import { defineStore } from 'pinia';
import { getInfo } from '@/api/login'
import { setToken, clearToken } from '@/utils/auth';
import { UserState, userInfo } from './types';

const useUserStore = defineStore('user', {
  state: (): UserState => ({
    user: {},
    roles: []
  }),

  getters: {
    userInfo(state: UserState): UserState {
      return { ...state };
    },
  },

  actions: {
    // 获取用户信息
    getInfo() {
      return new Promise((resolve, reject) => {
        getInfo().then(res => {
          this.setUserInfo(res)
          resolve(res)
        }).catch(error => {
          reject(error)
        })
      })
    },

    setUserInfo(res: userInfo) {
      // 如果没有任何权限，则赋予一个默认的权限，避免请求死循环
      if (res.roles.length === 0) {
        this.roles = ['ROLE_SYSTEM_DEFAULT']

      } else {
        this.roles = res.roles
      }
      this.user = res.user
    },


    // switchRoles() {
    //   return new Promise((resolve) => {
    //     this.role = this.role === 'user' ? 'admin' : 'user';
    //     resolve(this.role);
    //   });
    // },
    // // Set user's information
    // setInfo(partial: Partial<UserState>) {
    //   this.$patch(partial);
    // },

    // // Reset user's information
    // resetInfo() {
    //   this.$reset();
    // },

    // // Get user's information
    // async info() {
    //   const res = await getUserInfo();

    //   this.setInfo(res.data);
    // },

    // // Login
    // async login(loginForm: LoginData) {
    //   try {
    //     const res = await userLogin(loginForm);
    //     setToken(res.data.token);
    //   } catch (err) {
    //     clearToken();
    //     throw err;
    //   }
    // },

    // // Logout
    // async logout() {
    //   await userLogout();

    //   this.resetInfo();
    //   clearToken();
    // },
  },
});




export default useUserStore;
