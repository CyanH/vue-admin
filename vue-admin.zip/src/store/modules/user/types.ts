export interface UserState {
  user: object,
  roles: Array<string>
}


export interface userInfo {
  roles: Array<string>,
  user: object
}