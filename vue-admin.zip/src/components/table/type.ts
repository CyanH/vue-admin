export interface Page{
  index: Number,
  size: Number,
  total: Number
}