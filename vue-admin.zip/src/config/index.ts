const showLogo: Boolean = true; // 是否显示Logo顶部模块
const systemTitle = '后台管理系统' // 系统名称，用于显示在左上角模块，以及浏览器标题上使用,使用配置项
export {
  systemTitle
}