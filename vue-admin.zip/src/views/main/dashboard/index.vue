<template>
  <div class="box">
    我是首页
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
export default defineComponent({

})
</script>

<style lang="scss" scoped>
  .box {
    padding: 15px;
  }
</style>